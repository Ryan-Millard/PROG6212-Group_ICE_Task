public class CalendarIntegration //The CalendarIntegration class is for integrating event data with an external calendar service
{
    private readonly HttpClient _httpClient;//Initializes a new instance of the CalendarIntegration class with a provided HttpClient

    public CalendarIntegration(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<bool> IntegrateWithGoogleCalendarAsync(string eventData, string accessToken)//Asynchronously integrates event data with an external calendar service.
    {
    var request = new HttpRequestMessage(HttpMethod.Post, "https://www.googleapis.com/calendar/v3/calendars/primary/events");
    request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
    request.Content = new StringContent(eventData, Encoding.UTF8, "application/json");

    HttpResponseMessage response = await _httpClient.SendAsync(request);
    return response.IsSuccessStatusCode;//Returns true if the integration was successful.
    }

}
