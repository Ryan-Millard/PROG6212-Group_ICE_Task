public void ConfigureServices(IServiceCollection services)
{
    services.AddHttpClient<DataFetcher>();//Registers DataFetcher with an HttpClient instance for dependency injection
    services.AddHttpClient<CalendarIntegration>();//Registers CalendarIntegration with an HttpClient instance for dependency injection
    services.AddTransient<EventManager>();//Registers EventManager as a transient service
    services.AddTransient<EventProcessing>();//Registers EventProcessing as a transient service
}
