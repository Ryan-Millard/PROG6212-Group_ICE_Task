using System.Net.Http;
using System.Threading.Tasks;

public class DataFetcher//This class is for fetching data asynchronously from an external source
{
    private readonly HttpClient _httpClient;//Initializes a new instance of the DataFetcher class with a provided HttpClient, the HttpClient is used to send HTTP requests


    public DataFetcher(HttpClient httpClient)
    {
        _httpClient = httpClient;//Asynchronously fetches event data from a specified URL.
    }

    public async Task<string> FetchDataAsync(string url)
    {
        HttpResponseMessage response = await _httpClient.GetAsync(url);
        response.EnsureSuccessStatusCode();// Throws an exception if the HTTP response was not successful
        string responseBody = await response.Content.ReadAsStringAsync();
        return responseBody;// Returns the event data as a string
    }
}
