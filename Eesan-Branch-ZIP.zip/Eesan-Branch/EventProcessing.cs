public class EventProcessing
{
    private readonly EventManager _eventManager;

    public EventProcessing(EventManager eventManager)//Initializes a new instance of the EventProcessing class with a provided EventManager instance
    {
        _eventManager = eventManager;
    }

    public async Task ProcessEventsConcurrently(List<string> eventUrls, string calendarApiUrl)//Processes multiple events concurrently by managing them asynchronously
    {
        List<Task> tasks = new List<Task>();//List to hold all the asynchronous tasks for processing events

        foreach (var eventUrl in eventUrls)//Loop through each event URL and create a task to manage that event
        {
            tasks.Add(_eventManager.ManageEventAsync(eventUrl, calendarApiUrl));
        }

        await Task.WhenAll(tasks);//Await all tasks to complete
    }
}
